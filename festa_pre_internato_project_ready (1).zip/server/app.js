const express = require('express');
const session = require('express-session');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const rateLimit = require('express-rate-limit');
const cors = require('cors');
const dotenv = require('dotenv');

const { inserirComprovante, listarComprovantes, atualizarStatus, obterComprovantePorId } = require('./db');
const { verificarCredenciais, exigirAutenticacao } = require('./auth');

// Carregar variáveis de ambiente
dotenv.config({ path: path.resolve(__dirname, '..', '.env') });

const app = express();

// Configurar CORS: liberar apenas o domínio configurado
const allowedOrigin = process.env.BASE_URL || '';
app.use(cors({
  origin: allowedOrigin,
  credentials: true
}));

// Servir arquivos estáticos da pasta public
app.use(express.static(path.join(__dirname, '..', 'public')));

// Configurar sessões (cookie HttpOnly, SameSite Strict)
app.use(session({
  secret: crypto.randomBytes(32).toString('hex'),
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'strict',
    maxAge: 12 * 60 * 60 * 1000 // 12 horas
  }
}));

// Rate limiter para evitar spam de uploads
const uploadLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: { erro: 'Limite de requisições excedido', codigo: 'rate_limit' }
});

// Configurar armazenamento de arquivos com Multer
const uploadDirectory = process.env.DIRETORIO_UPLOADS || path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadDirectory)) {
  fs.mkdirSync(uploadDirectory, { recursive: true });
}
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDirectory);
  },
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname).toLowerCase();
    const uuid = crypto.randomUUID();
    cb(null, uuid + ext);
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024
  },
  fileFilter: function (req, file, cb) {
    const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Tipo de arquivo não permitido'));
    }
  }
});

// Rota principal (serve index.html)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// POST /api/comprovantes
app.post('/api/comprovantes', uploadLimiter, (req, res) => {
  upload.single('arquivo')(req, res, async function (err) {
    if (err instanceof multer.MulterError) {
      return res.status(400).json({ erro: 'Erro no upload', codigo: 'upload_error' });
    } else if (err) {
      return res.status(400).json({ erro: err.message, codigo: 'invalid_file' });
    }
    const { nome_completo, quantidade } = req.body;
    if (!nome_completo || typeof nome_completo !== 'string' || nome_completo.trim().length < 3 || nome_completo.trim().length > 80) {
      return res.status(400).json({ erro: 'Nome inválido', codigo: 'invalid_name' });
    }
    const qty = parseInt(quantidade, 10);
    if (isNaN(qty) || qty < 1 || qty > 10) {
      return res.status(400).json({ erro: 'Quantidade inválida', codigo: 'invalid_quantity' });
    }
    if (!req.file) {
      return res.status(400).json({ erro: 'Arquivo ausente', codigo: 'no_file' });
    }

    const arquivo = req.file;
    const timestamp = Date.now().toString(36);
    const randomPart = crypto.randomBytes(3).toString('hex');
    const protocolo = `${timestamp}-${randomPart}`.toUpperCase();

    try {
      await inserirComprovante(
        protocolo,
        nome_completo.trim(),
        qty,
        arquivo.filename,
        arquivo.mimetype,
        arquivo.size
      );
      return res.json({ protocolo, mensagem: 'Recebido' });
    } catch (dbErr) {
      console.error(dbErr);
      return res.status(500).json({ erro: 'Erro ao salvar comprovante', codigo: 'db_error' });
    }
  });
});

// Página de login da comissão
app.get('/admin/login', (req, res) => {
  const html = `
  <!DOCTYPE html>
  <html lang="pt-BR">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Login Administração</title>
    <style>
      body { font-family: sans-serif; background: #f5f5f5; display: flex; justify-content: center; align-items: center; height: 100vh; }
      .login-card { background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); width: 300px; }
      h2 { margin-top: 0; text-align: center; }
      label { display: block; margin-top: 10px; }
      input { width: 100%; padding: 8px; margin-top: 5px; border-radius: 4px; border: 1px solid #ccc; }
      button { width: 100%; margin-top: 15px; padding: 10px; border: none; border-radius: 4px; background-color: #007bff; color: white; cursor: pointer; }
      button:focus { outline: 3px solid #0056b3; }
    </style>
  </head>
  <body>
    <form class="login-card" method="POST" action="/admin/sessao">
      <h2>Administração</h2>
      <label for="usuario">Usuário</label>
      <input type="text" id="usuario" name="usuario" required>
      <label for="senha">Senha</label>
      <input type="password" id="senha" name="senha" required>
      <button type="submit">Entrar</button>
    </form>
  </body>
  </html>
  `;
  res.send(html);
});

app.use(express.urlencoded({ extended: true }));

app.post('/admin/sessao', async (req, res) => {
  const { usuario, senha } = req.body;
  const adminUsuario = process.env.ADMIN_USUARIO;
  const adminSenhaHash = process.env.ADMIN_SENHA_HASH;
  if (!adminUsuario || !adminSenhaHash) {
    return res.status(500).send('Credenciais não configuradas');
  }
  const ok = await verificarCredenciais(usuario, senha, adminUsuario, adminSenhaHash);
  if (ok) {
    req.session.autenticado = true;
    req.session.usuario = usuario;
    return res.redirect('/admin');
  } else {
    return res.status(401).send('Credenciais inválidas');
  }
});

app.post('/admin/sair', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/admin/login');
  });
});

app.get('/admin', exigirAutenticacao, (req, res) => {
  const html = `
  <!DOCTYPE html>
  <html lang="pt-BR">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Painel Administrativo</title>
    <style>
      body { font-family: sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }
      h1 { text-align: center; }
      table { width: 100%; border-collapse: collapse; margin-top: 20px; }
      th, td { padding: 8px; border: 1px solid #ddd; text-align: left; }
      th { background-color: #f0f0f0; }
      tr:nth-child(even) { background-color: #fafafa; }
      .status-select { width: 100%; }
      .filter-container { display: flex; gap: 10px; margin-bottom: 10px; }
      .filter-container input, .filter-container select { padding: 5px; }
      .export-btn { margin-top: 10px; padding: 8px 12px; background: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer; }
    </style>
  </head>
  <body>
    <h1>Comprovantes Recebidos</h1>
    <div class="filter-container">
      <input type="text" id="filtroNome" placeholder="Buscar por nome">
      <select id="filtroStatus">
        <option value="">Todos</option>
        <option value="pendente">Pendente</option>
        <option value="aprovado">Aprovado</option>
        <option value="recusado">Recusado</option>
      </select>
      <button id="btnFiltrar">Filtrar</button>
      <form method="POST" action="/admin/sair" style="margin-left:auto;">
        <button type="submit">Sair</button>
      </form>
    </div>
    <button class="export-btn" id="exportCsv">Exportar CSV</button>
    <table>
      <thead>
        <tr>
          <th>Protocolo</th>
          <th>Nome</th>
          <th>Quantidade</th>
          <th>Data/Hora</th>
          <th>Status</th>
          <th>Arquivo</th>
        </tr>
      </thead>
      <tbody id="tabelaCorpo"></tbody>
    </table>
    <script>
      async function carregarComprovantes() {
        const nome = document.getElementById('filtroNome').value;
        const status = document.getElementById('filtroStatus').value;
        const params = new URLSearchParams();
        if (nome) params.append('nome', nome);
        if (status) params.append('status', status);
        const res = await fetch('/admin/api/comprovantes?' + params.toString(), { credentials: 'include' });
        if (res.ok) {
          const data = await res.json();
          const tbody = document.getElementById('tabelaCorpo');
          tbody.innerHTML = '';
          data.forEach(item => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
              <td>${item.protocolo}</td>
              <td>${item.nome}</td>
              <td>${item.quantidade}</td>
              <td>${new Date(item.criado_em).toLocaleString('pt-BR')}</td>
              <td>
                <select class="status-select" data-id="${item.id}">
                  <option value="pendente" ${item.status === 'pendente' ? 'selected' : ''}>Pendente</option>
                  <option value="aprovado" ${item.status === 'aprovado' ? 'selected' : ''}>Aprovado</option>
                  <option value="recusado" ${item.status === 'recusado' ? 'selected' : ''}>Recusado</option>
                </select>
              </td>
              <td><a href="/admin/arquivo/${item.id}" target="_blank">Ver</a></td>
            `;
            tbody.appendChild(tr);
          });
          document.querySelectorAll('.status-select').forEach(select => {
            select.addEventListener('change', async function() {
              const id = this.getAttribute('data-id');
              const novoStatus = this.value;
              await fetch('/admin/comprovantes/' + id + '/status', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ status: novoStatus })
              });
            });
          });
        }
      }

      document.getElementById('btnFiltrar').addEventListener('click', carregarComprovantes);
      document.getElementById('filtroNome').addEventListener('input', function(event) {
        if (!this.value) carregarComprovantes();
      });
      document.getElementById('filtroStatus').addEventListener('change', carregarComprovantes);
      document.getElementById('exportCsv').addEventListener('click', () => {
        window.open('/admin/exportar.csv', '_blank');
      });
      carregarComprovantes();
    </script>
  </body>
  </html>
  `;
  res.send(html);
});

app.get('/admin/api/comprovantes', exigirAutenticacao, async (req, res) => {
  const { nome, status } = req.query;
  try {
    const lista = await listarComprovantes({ nome, status });
    res.json(lista);
  } catch (err) {
    res.status(500).json({ erro: 'Erro ao listar comprovantes', codigo: 'db_error' });
  }
});

app.post('/admin/comprovantes/:id/status', exigirAutenticacao, express.json(), async (req, res) => {
  const id = req.params.id;
  const { status } = req.body;
  if (!['pendente', 'aprovado', 'recusado'].includes(status)) {
    return res.status(400).json({ erro: 'Status inválido', codigo: 'invalid_status' });
  }
  try {
    await atualizarStatus(id, status);
    res.json({ mensagem: 'Status atualizado' });
  } catch (err) {
    res.status(500).json({ erro: 'Erro ao atualizar status', codigo: 'db_error' });
  }
});

app.get('/admin/exportar.csv', exigirAutenticacao, async (req, res) => {
  try {
    const lista = await listarComprovantes({});
    let csv = 'Protocolo,Nome,Quantidade,Data/Hora,Status,Link
';
    lista.forEach(item => {
      const dataHora = new Date(item.criado_em).toISOString();
      const link = `${process.env.BASE_URL || ''}/admin/arquivo/${item.id}`;
      csv += `${item.protocolo},${item.nome},${item.quantidade},${dataHora},${item.status},${link}
`;
    });
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="comprovantes.csv"');
    res.send(csv);
  } catch (err) {
    res.status(500).send('Erro ao exportar CSV');
  }
});

app.get('/admin/arquivo/:id', exigirAutenticacao, async (req, res) => {
  const id = req.params.id;
  try {
    const comprovante = await obterComprovantePorId(id);
    if (!comprovante) {
      return res.status(404).send('Arquivo não encontrado');
    }
    const filePath = path.join(uploadDirectory, comprovante.caminho_arquivo);
    if (!fs.existsSync(filePath)) {
      return res.status(404).send('Arquivo não encontrado');
    }
    res.sendFile(filePath);
  } catch (err) {
    res.status(500).send('Erro ao obter arquivo');
  }
});

const port = process.env.PORTA || 8080;
app.listen(port, () => {
  console.log('Servidor ouvindo na porta ' + port);
});
