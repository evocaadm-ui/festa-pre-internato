const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

// Caminho absoluto para o banco de dados SQLite
const dbFile = path.resolve(__dirname, '..', 'data', 'db.sqlite');

// Garantir que o diretório exista
const dataDir = path.dirname(dbFile);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const db = new sqlite3.Database(dbFile);

// Criar tabela de comprovantes se não existir
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS comprovantes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      protocolo TEXT UNIQUE,
      nome TEXT NOT NULL,
      quantidade INTEGER NOT NULL,
      caminho_arquivo TEXT NOT NULL,
      tipo_mime TEXT NOT NULL,
      tamanho_bytes INTEGER NOT NULL,
      criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
      status TEXT DEFAULT 'pendente'
    )
  `);
});

// Função para inserir um novo comprovante
function inserirComprovante(protocolo, nome, quantidade, caminhoArquivo, tipoMime, tamanhoBytes) {
  return new Promise((resolve, reject) => {
    db.run(
      'INSERT INTO comprovantes (protocolo, nome, quantidade, caminho_arquivo, tipo_mime, tamanho_bytes) VALUES (?, ?, ?, ?, ?, ?)',
      [protocolo, nome, quantidade, caminhoArquivo, tipoMime, tamanhoBytes],
      function(err) {
        if (err) return reject(err);
        resolve(this.lastID);
      }
    );
  });
}

// Função para listar comprovantes com filtros opcionais
function listarComprovantes(filter = {}) {
  return new Promise((resolve, reject) => {
    let sql = 'SELECT id, protocolo, nome, quantidade, caminho_arquivo, tipo_mime, tamanho_bytes, criado_em, status FROM comprovantes';
    const params = [];
    const conditions = [];
    if (filter.nome) {
      conditions.push('nome LIKE ?');
      params.push(`%${filter.nome}%`);
    }
    if (filter.status) {
      conditions.push('status = ?');
      params.push(filter.status);
    }
    if (conditions.length) {
      sql += ' WHERE ' + conditions.join(' AND ');
    }
    sql += ' ORDER BY criado_em DESC';
    db.all(sql, params, (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}

// Função para atualizar o status de um comprovante
function atualizarStatus(id, status) {
  return new Promise((resolve, reject) => {
    db.run('UPDATE comprovantes SET status = ? WHERE id = ?', [status, id], function(err) {
      if (err) return reject(err);
      resolve(this.changes);
    });
  });
}

// Obter comprovante por ID
function obterComprovantePorId(id) {
  return new Promise((resolve, reject) => {
    db.get('SELECT * FROM comprovantes WHERE id = ?', [id], (err, row) => {
      if (err) return reject(err);
      resolve(row);
    });
  });
}

module.exports = {
  inserirComprovante,
  listarComprovantes,
  atualizarStatus,
  obterComprovantePorId
};
