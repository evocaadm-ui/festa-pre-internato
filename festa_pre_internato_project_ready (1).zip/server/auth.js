const bcrypt = require('bcrypt');

// Função para verificar credenciais de login
async function verificarCredenciais(usuario, senha, usuarioEnv, senhaHashEnv) {
  if (usuario !== usuarioEnv) return false;
  // Comparar senha fornecida com hash salvo
  const ok = await bcrypt.compare(senha, senhaHashEnv);
  return ok;
}

// Middleware para exigir autenticação
function exigirAutenticacao(req, res, next) {
  if (req.session && req.session.autenticado) {
    return next();
  }
  return res.redirect('/admin/login');
}

module.exports = {
  verificarCredenciais,
  exigirAutenticacao
};
